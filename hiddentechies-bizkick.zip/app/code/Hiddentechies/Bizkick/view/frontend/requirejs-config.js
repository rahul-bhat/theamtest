var config = {
    map: {
        '*': {
            bizkickowlcarousel: 'Hiddentechies_Bizkick/js/owl.carousel',
        }
    }
};