var config = {
    map: {
        '*': {
            baseowlcarousel: 'Hiddentechies_Base/js/owl.carousel',
        }
    }
};